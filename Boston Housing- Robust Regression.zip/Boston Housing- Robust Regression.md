
#### Importing Libraries


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import dfply as dplyr
%matplotlib inline
```


```python
df= pd.read_csv('Housing.data',delim_whitespace=True,header=None)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>10</th>
      <th>11</th>
      <th>12</th>
      <th>13</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00632</td>
      <td>18.0</td>
      <td>2.31</td>
      <td>0</td>
      <td>0.538</td>
      <td>6.575</td>
      <td>65.2</td>
      <td>4.0900</td>
      <td>1</td>
      <td>296.0</td>
      <td>15.3</td>
      <td>396.90</td>
      <td>4.98</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.02731</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>6.421</td>
      <td>78.9</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242.0</td>
      <td>17.8</td>
      <td>396.90</td>
      <td>9.14</td>
      <td>21.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.02729</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>7.185</td>
      <td>61.1</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242.0</td>
      <td>17.8</td>
      <td>392.83</td>
      <td>4.03</td>
      <td>34.7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03237</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>6.998</td>
      <td>45.8</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222.0</td>
      <td>18.7</td>
      <td>394.63</td>
      <td>2.94</td>
      <td>33.4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.06905</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>7.147</td>
      <td>54.2</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222.0</td>
      <td>18.7</td>
      <td>396.90</td>
      <td>5.33</td>
      <td>36.2</td>
    </tr>
  </tbody>
</table>
</div>




```python
d=pd.read_table('housing.txt')
```


```python
header= ['CRIM','ZN','INDUS','CHAS','NOX','RM','AGE','DIS','RAD','TAX','PTRATIO','B','LSTAT','MEDV']
```


```python
df.columns= header
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>B</th>
      <th>LSTAT</th>
      <th>MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00632</td>
      <td>18.0</td>
      <td>2.31</td>
      <td>0</td>
      <td>0.538</td>
      <td>6.575</td>
      <td>65.2</td>
      <td>4.0900</td>
      <td>1</td>
      <td>296.0</td>
      <td>15.3</td>
      <td>396.90</td>
      <td>4.98</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.02731</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>6.421</td>
      <td>78.9</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242.0</td>
      <td>17.8</td>
      <td>396.90</td>
      <td>9.14</td>
      <td>21.6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.02729</td>
      <td>0.0</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.469</td>
      <td>7.185</td>
      <td>61.1</td>
      <td>4.9671</td>
      <td>2</td>
      <td>242.0</td>
      <td>17.8</td>
      <td>392.83</td>
      <td>4.03</td>
      <td>34.7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03237</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>6.998</td>
      <td>45.8</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222.0</td>
      <td>18.7</td>
      <td>394.63</td>
      <td>2.94</td>
      <td>33.4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.06905</td>
      <td>0.0</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.458</td>
      <td>7.147</td>
      <td>54.2</td>
      <td>6.0622</td>
      <td>3</td>
      <td>222.0</td>
      <td>18.7</td>
      <td>396.90</td>
      <td>5.33</td>
      <td>36.2</td>
    </tr>
  </tbody>
</table>
</div>



## Exploratory Data Anaysis (EDA)


```python
pd.options.display.float_format = '{:,.2f}'.format
df.describe().transpose()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>CRIM</th>
      <td>506.00</td>
      <td>3.61</td>
      <td>8.60</td>
      <td>0.01</td>
      <td>0.08</td>
      <td>0.26</td>
      <td>3.68</td>
      <td>88.98</td>
    </tr>
    <tr>
      <th>ZN</th>
      <td>506.00</td>
      <td>11.36</td>
      <td>23.32</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>12.50</td>
      <td>100.00</td>
    </tr>
    <tr>
      <th>INDUS</th>
      <td>506.00</td>
      <td>11.14</td>
      <td>6.86</td>
      <td>0.46</td>
      <td>5.19</td>
      <td>9.69</td>
      <td>18.10</td>
      <td>27.74</td>
    </tr>
    <tr>
      <th>CHAS</th>
      <td>506.00</td>
      <td>0.07</td>
      <td>0.25</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>NOX</th>
      <td>506.00</td>
      <td>0.55</td>
      <td>0.12</td>
      <td>0.39</td>
      <td>0.45</td>
      <td>0.54</td>
      <td>0.62</td>
      <td>0.87</td>
    </tr>
    <tr>
      <th>RM</th>
      <td>506.00</td>
      <td>6.28</td>
      <td>0.70</td>
      <td>3.56</td>
      <td>5.89</td>
      <td>6.21</td>
      <td>6.62</td>
      <td>8.78</td>
    </tr>
    <tr>
      <th>AGE</th>
      <td>506.00</td>
      <td>68.57</td>
      <td>28.15</td>
      <td>2.90</td>
      <td>45.02</td>
      <td>77.50</td>
      <td>94.07</td>
      <td>100.00</td>
    </tr>
    <tr>
      <th>DIS</th>
      <td>506.00</td>
      <td>3.80</td>
      <td>2.11</td>
      <td>1.13</td>
      <td>2.10</td>
      <td>3.21</td>
      <td>5.19</td>
      <td>12.13</td>
    </tr>
    <tr>
      <th>RAD</th>
      <td>506.00</td>
      <td>9.55</td>
      <td>8.71</td>
      <td>1.00</td>
      <td>4.00</td>
      <td>5.00</td>
      <td>24.00</td>
      <td>24.00</td>
    </tr>
    <tr>
      <th>TAX</th>
      <td>506.00</td>
      <td>408.24</td>
      <td>168.54</td>
      <td>187.00</td>
      <td>279.00</td>
      <td>330.00</td>
      <td>666.00</td>
      <td>711.00</td>
    </tr>
    <tr>
      <th>PTRATIO</th>
      <td>506.00</td>
      <td>18.46</td>
      <td>2.16</td>
      <td>12.60</td>
      <td>17.40</td>
      <td>19.05</td>
      <td>20.20</td>
      <td>22.00</td>
    </tr>
    <tr>
      <th>B</th>
      <td>506.00</td>
      <td>356.67</td>
      <td>91.29</td>
      <td>0.32</td>
      <td>375.38</td>
      <td>391.44</td>
      <td>396.23</td>
      <td>396.90</td>
    </tr>
    <tr>
      <th>LSTAT</th>
      <td>506.00</td>
      <td>12.65</td>
      <td>7.14</td>
      <td>1.73</td>
      <td>6.95</td>
      <td>11.36</td>
      <td>16.96</td>
      <td>37.97</td>
    </tr>
    <tr>
      <th>MEDV</th>
      <td>506.00</td>
      <td>22.53</td>
      <td>9.20</td>
      <td>5.00</td>
      <td>17.02</td>
      <td>21.20</td>
      <td>25.00</td>
      <td>50.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.pairplot(df,size=1.5)
plt.show()
```


![png](output_10_0.png)



```python
col_study = ['ZN', 'INDUS', 'NOX', 'RM']

```


```python
sns.pairplot(df[col_study],size=2.2)
plt.show()
```


![png](output_12_0.png)



```python
col_study2 = ['PTRATIO', 'B', 'LSTAT', 'MEDV']

```


```python
sns.pairplot(df[col_study2],size=2)
plt.show()
```


![png](output_14_0.png)


### Correlation Analysis and Feature Selection¶



```python
pd.options.display.float_format = '{:,.2f}'.format
df.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>B</th>
      <th>LSTAT</th>
      <th>MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>CRIM</th>
      <td>1.00</td>
      <td>-0.20</td>
      <td>0.41</td>
      <td>-0.06</td>
      <td>0.42</td>
      <td>-0.22</td>
      <td>0.35</td>
      <td>-0.38</td>
      <td>0.63</td>
      <td>0.58</td>
      <td>0.29</td>
      <td>-0.39</td>
      <td>0.46</td>
      <td>-0.39</td>
    </tr>
    <tr>
      <th>ZN</th>
      <td>-0.20</td>
      <td>1.00</td>
      <td>-0.53</td>
      <td>-0.04</td>
      <td>-0.52</td>
      <td>0.31</td>
      <td>-0.57</td>
      <td>0.66</td>
      <td>-0.31</td>
      <td>-0.31</td>
      <td>-0.39</td>
      <td>0.18</td>
      <td>-0.41</td>
      <td>0.36</td>
    </tr>
    <tr>
      <th>INDUS</th>
      <td>0.41</td>
      <td>-0.53</td>
      <td>1.00</td>
      <td>0.06</td>
      <td>0.76</td>
      <td>-0.39</td>
      <td>0.64</td>
      <td>-0.71</td>
      <td>0.60</td>
      <td>0.72</td>
      <td>0.38</td>
      <td>-0.36</td>
      <td>0.60</td>
      <td>-0.48</td>
    </tr>
    <tr>
      <th>CHAS</th>
      <td>-0.06</td>
      <td>-0.04</td>
      <td>0.06</td>
      <td>1.00</td>
      <td>0.09</td>
      <td>0.09</td>
      <td>0.09</td>
      <td>-0.10</td>
      <td>-0.01</td>
      <td>-0.04</td>
      <td>-0.12</td>
      <td>0.05</td>
      <td>-0.05</td>
      <td>0.18</td>
    </tr>
    <tr>
      <th>NOX</th>
      <td>0.42</td>
      <td>-0.52</td>
      <td>0.76</td>
      <td>0.09</td>
      <td>1.00</td>
      <td>-0.30</td>
      <td>0.73</td>
      <td>-0.77</td>
      <td>0.61</td>
      <td>0.67</td>
      <td>0.19</td>
      <td>-0.38</td>
      <td>0.59</td>
      <td>-0.43</td>
    </tr>
    <tr>
      <th>RM</th>
      <td>-0.22</td>
      <td>0.31</td>
      <td>-0.39</td>
      <td>0.09</td>
      <td>-0.30</td>
      <td>1.00</td>
      <td>-0.24</td>
      <td>0.21</td>
      <td>-0.21</td>
      <td>-0.29</td>
      <td>-0.36</td>
      <td>0.13</td>
      <td>-0.61</td>
      <td>0.70</td>
    </tr>
    <tr>
      <th>AGE</th>
      <td>0.35</td>
      <td>-0.57</td>
      <td>0.64</td>
      <td>0.09</td>
      <td>0.73</td>
      <td>-0.24</td>
      <td>1.00</td>
      <td>-0.75</td>
      <td>0.46</td>
      <td>0.51</td>
      <td>0.26</td>
      <td>-0.27</td>
      <td>0.60</td>
      <td>-0.38</td>
    </tr>
    <tr>
      <th>DIS</th>
      <td>-0.38</td>
      <td>0.66</td>
      <td>-0.71</td>
      <td>-0.10</td>
      <td>-0.77</td>
      <td>0.21</td>
      <td>-0.75</td>
      <td>1.00</td>
      <td>-0.49</td>
      <td>-0.53</td>
      <td>-0.23</td>
      <td>0.29</td>
      <td>-0.50</td>
      <td>0.25</td>
    </tr>
    <tr>
      <th>RAD</th>
      <td>0.63</td>
      <td>-0.31</td>
      <td>0.60</td>
      <td>-0.01</td>
      <td>0.61</td>
      <td>-0.21</td>
      <td>0.46</td>
      <td>-0.49</td>
      <td>1.00</td>
      <td>0.91</td>
      <td>0.46</td>
      <td>-0.44</td>
      <td>0.49</td>
      <td>-0.38</td>
    </tr>
    <tr>
      <th>TAX</th>
      <td>0.58</td>
      <td>-0.31</td>
      <td>0.72</td>
      <td>-0.04</td>
      <td>0.67</td>
      <td>-0.29</td>
      <td>0.51</td>
      <td>-0.53</td>
      <td>0.91</td>
      <td>1.00</td>
      <td>0.46</td>
      <td>-0.44</td>
      <td>0.54</td>
      <td>-0.47</td>
    </tr>
    <tr>
      <th>PTRATIO</th>
      <td>0.29</td>
      <td>-0.39</td>
      <td>0.38</td>
      <td>-0.12</td>
      <td>0.19</td>
      <td>-0.36</td>
      <td>0.26</td>
      <td>-0.23</td>
      <td>0.46</td>
      <td>0.46</td>
      <td>1.00</td>
      <td>-0.18</td>
      <td>0.37</td>
      <td>-0.51</td>
    </tr>
    <tr>
      <th>B</th>
      <td>-0.39</td>
      <td>0.18</td>
      <td>-0.36</td>
      <td>0.05</td>
      <td>-0.38</td>
      <td>0.13</td>
      <td>-0.27</td>
      <td>0.29</td>
      <td>-0.44</td>
      <td>-0.44</td>
      <td>-0.18</td>
      <td>1.00</td>
      <td>-0.37</td>
      <td>0.33</td>
    </tr>
    <tr>
      <th>LSTAT</th>
      <td>0.46</td>
      <td>-0.41</td>
      <td>0.60</td>
      <td>-0.05</td>
      <td>0.59</td>
      <td>-0.61</td>
      <td>0.60</td>
      <td>-0.50</td>
      <td>0.49</td>
      <td>0.54</td>
      <td>0.37</td>
      <td>-0.37</td>
      <td>1.00</td>
      <td>-0.74</td>
    </tr>
    <tr>
      <th>MEDV</th>
      <td>-0.39</td>
      <td>0.36</td>
      <td>-0.48</td>
      <td>0.18</td>
      <td>-0.43</td>
      <td>0.70</td>
      <td>-0.38</td>
      <td>0.25</td>
      <td>-0.38</td>
      <td>-0.47</td>
      <td>-0.51</td>
      <td>0.33</td>
      <td>-0.74</td>
      <td>1.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(16,10))
sns.heatmap(df.corr(), annot=True,robust=True)
plt.show()
```


![png](output_17_0.png)



```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CRIM</th>
      <th>ZN</th>
      <th>INDUS</th>
      <th>CHAS</th>
      <th>NOX</th>
      <th>RM</th>
      <th>AGE</th>
      <th>DIS</th>
      <th>RAD</th>
      <th>TAX</th>
      <th>PTRATIO</th>
      <th>B</th>
      <th>LSTAT</th>
      <th>MEDV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.01</td>
      <td>18.00</td>
      <td>2.31</td>
      <td>0</td>
      <td>0.54</td>
      <td>6.58</td>
      <td>65.20</td>
      <td>4.09</td>
      <td>1</td>
      <td>296.00</td>
      <td>15.30</td>
      <td>396.90</td>
      <td>4.98</td>
      <td>24.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.03</td>
      <td>0.00</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.47</td>
      <td>6.42</td>
      <td>78.90</td>
      <td>4.97</td>
      <td>2</td>
      <td>242.00</td>
      <td>17.80</td>
      <td>396.90</td>
      <td>9.14</td>
      <td>21.60</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.03</td>
      <td>0.00</td>
      <td>7.07</td>
      <td>0</td>
      <td>0.47</td>
      <td>7.18</td>
      <td>61.10</td>
      <td>4.97</td>
      <td>2</td>
      <td>242.00</td>
      <td>17.80</td>
      <td>392.83</td>
      <td>4.03</td>
      <td>34.70</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.03</td>
      <td>0.00</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.46</td>
      <td>7.00</td>
      <td>45.80</td>
      <td>6.06</td>
      <td>3</td>
      <td>222.00</td>
      <td>18.70</td>
      <td>394.63</td>
      <td>2.94</td>
      <td>33.40</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.07</td>
      <td>0.00</td>
      <td>2.18</td>
      <td>0</td>
      <td>0.46</td>
      <td>7.15</td>
      <td>54.20</td>
      <td>6.06</td>
      <td>3</td>
      <td>222.00</td>
      <td>18.70</td>
      <td>396.90</td>
      <td>5.33</td>
      <td>36.20</td>
    </tr>
  </tbody>
</table>
</div>




```python
X = df['RM'].values.reshape(-1,1)
y = df['MEDV'].values
```


```python
from sklearn.linear_model import RANSACRegressor
```


```python
ransac = RANSACRegressor()
ransac.fit(X, y)

```




    RANSACRegressor(base_estimator=None, is_data_valid=None, is_model_valid=None,
            loss='absolute_loss', max_skips=inf, max_trials=100,
            min_samples=None, random_state=None, residual_metric=None,
            residual_threshold=None, stop_n_inliers=inf, stop_probability=0.99,
            stop_score=inf)




```python
inlier_mask = ransac.inlier_mask_
outlier_mask = np.logical_not(inlier_mask)
```


```python
np.arange(3, 10, 1)

```




    array([3, 4, 5, 6, 7, 8, 9])




```python
line_X = np.arange(3, 10, 1)
line_y_ransac = ransac.predict(line_X.reshape(-1, 1))

```


```python
sns.set(style='darkgrid', context='notebook')
plt.figure(figsize=(12,10));
plt.scatter(X[inlier_mask], y[inlier_mask], 
            c='blue', marker='o', label='Inliers')
plt.scatter(X[outlier_mask], y[outlier_mask],
            c='brown', marker='s', label='Outliers')
plt.plot(line_X, line_y_ransac, color='red')
plt.xlabel('average number of rooms per dwelling')
plt.ylabel("Median value of owner-occupied homes in $1000's")
plt.legend(loc='upper left')
plt.show()

```


![png](output_25_0.png)



```python
ransac.estimator_
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=False)




```python
ransac.estimator_.coef_
```




    array([9.44929914])




```python
ransac.estimator_.intercept_
```




    -37.167988325967514




```python
X = df['LSTAT'].values.reshape(-1,1)
y = df['MEDV'].values
ransac.fit(X, y)
inlier_mask = ransac.inlier_mask_
outlier_mask = np.logical_not(inlier_mask)
line_X = np.arange(0, 40, 1)
line_y_ransac = ransac.predict(line_X.reshape(-1, 1))
```


```python
sns.set(style='darkgrid', context='notebook')
plt.figure(figsize=(12,10));
plt.scatter(X[inlier_mask], y[inlier_mask], 
            c='blue', marker='o', label='Inliers')
plt.scatter(X[outlier_mask], y[outlier_mask],
            c='brown', marker='s', label='Outliers')
plt.plot(line_X, line_y_ransac, color='red')
plt.xlabel('% lower status of the population')
plt.ylabel("Median value of owner-occupied homes in $1000's")
plt.legend(loc='upper right')
plt.show()
```


![png](output_30_0.png)

